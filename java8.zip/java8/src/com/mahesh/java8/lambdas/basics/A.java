package com.mahesh.java8.lambdas.basics;


@FunctionalInterface
public interface A {
	
	void myMethod();
	
}
